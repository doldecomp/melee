This version is not a real version but an edited CW 1.2.5 compiler. This performs the profile hack found by EpochFlame intended to be used with frank.py.
